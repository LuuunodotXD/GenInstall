#!/bin/sh
# 10-limine.sh — build do limine (bootloader UEFI + BIOS)
. "$(dirname "$0")/common.sh"

VERSION=8.0.3
URL="https://github.com/limine-bootloader/limine/releases/download/v$VERSION/limine-$VERSION.tar.xz"

step "limine $VERSION"

fetch "$URL"
extract "$URL"

cd "$BUILD_DIR/limine-$VERSION"

./configure --prefix=/usr
make -j"$JOBS"
make DESTDIR="$UTILS" install

echo "  limine $VERSION done."
