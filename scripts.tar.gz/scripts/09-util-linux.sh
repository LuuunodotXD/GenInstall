#!/bin/sh
# 09-util-linux.sh — build do util-linux (fdisk, mount, etc.)
. "$(dirname "$0")/common.sh"

VERSION=2.40.2
URL="https://mirrors.edge.kernel.org/pub/linux/utils/util-linux/v2.40/util-linux-$VERSION.tar.xz"

step "util-linux $VERSION"

fetch "$URL"
extract "$URL"

cd "$BUILD_DIR/util-linux-$VERSION"

./configure \
    --prefix=/usr \
    --enable-static \
    --disable-shared \
    --without-python \
    --without-systemd \
    --without-udev \
    --disable-nls \
    --disable-asciidoc \
    CFLAGS="$CFLAGS"

make -j"$JOBS"
make DESTDIR="$UTILS" install

echo "  util-linux $VERSION done."
