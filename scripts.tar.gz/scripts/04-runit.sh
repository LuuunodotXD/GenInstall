#!/bin/sh
# 04-runit.sh — build do runit (init e supervisionamento de serviços)
. "$(dirname "$0")/common.sh"

VERSION=2.1.2
URL="http://smarden.org/runit/runit-$VERSION.tar.gz"

step "runit $VERSION"

fetch "$URL"
extract "$URL"

# o tarball extrai em admin/runit-VERSION
cd "$BUILD_DIR/admin/runit-$VERSION"

# define o compilador e flags
echo "gcc $CFLAGS -static" > src/conf-cc
echo "gcc -static" > src/conf-ld

make -j"$JOBS"

# instala os binários manualmente
mkdir -p "$BASE/sbin" "$BASE/usr/bin"
for bin in runit runit-init chpst runsv runsvdir sv svlogd utmpset; do
    [ -f "command/$bin" ] && install -m755 "command/$bin" "$BASE/sbin/"
done

echo "  runit $VERSION done."
