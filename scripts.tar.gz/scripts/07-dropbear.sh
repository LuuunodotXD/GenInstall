#!/bin/sh
# 07-dropbear.sh — build do Dropbear (SSH leve)
. "$(dirname "$0")/common.sh"

VERSION=2024.86
URL="https://matt.ucc.asn.au/dropbear/releases/dropbear-$VERSION.tar.bz2"

step "dropbear $VERSION"

fetch "$URL"
extract "$URL"

cd "$BUILD_DIR/dropbear-$VERSION"

./configure \
    --prefix=/usr \
    --disable-zlib \
    --enable-static \
    CFLAGS="$CFLAGS"

make -j"$JOBS"
make DESTDIR="$NETWORK" install

echo "  dropbear $VERSION done."
