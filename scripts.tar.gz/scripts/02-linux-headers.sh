#!/bin/sh
# 02-linux-headers.sh — instala os headers do kernel no staging
. "$(dirname "$0")/common.sh"

VERSION=6.1.187
URL="https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-$VERSION.tar.xz"

step "linux headers $VERSION"

fetch "$URL"

# só extrai se ainda não foi extraído (o kernel usa o mesmo tarball)
[ ! -d "$BUILD_DIR/linux-$VERSION" ] && extract "$URL"

cd "$BUILD_DIR/linux-$VERSION"

make ARCH=x86_64 INSTALL_HDR_PATH="$BASE/usr" headers_install

echo "  linux headers $VERSION done."
