#!/bin/sh
# common.sh — variáveis e funções compartilhadas entre os scripts de build
# carregado via: . "$(dirname "$0")/common.sh"

BASEROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SOURCES="$BASEROOT_DIR/sources"
BUILD_DIR="$BASEROOT_DIR/build"
ROOTFS="$BASEROOT_DIR/rootfs"
ISO_DIR="$BASEROOT_DIR/iso"
OUTPUT="$BASEROOT_DIR/output"

# staging dirs pra cada grupo de pacotes
BASE="$ROOTFS/base"
NETWORK="$ROOTFS/network"
UTILS="$ROOTFS/utils"
EXTRA="$ROOTFS/extra"
SCRIPTS_PKG="$ROOTFS/scripts"

# flags de compilação — sem march=native pra garantir compatibilidade
CFLAGS="-O2 -march=x86-64 -mtune=generic -pipe"
CXXFLAGS="$CFLAGS"
JOBS="$(nproc)"
export CFLAGS CXXFLAGS

# baixa um arquivo se ainda não existir
fetch() {
    url="$1"
    file="$SOURCES/$(basename "$url")"
    [ -f "$file" ] && return 0
    echo "  fetching $(basename "$url")..."
    wget -q -O "$file" "$url" || {
        echo "error: failed to fetch $url"
        rm -f "$file"
        exit 1
    }
}

# extrai um tarball no build dir
extract() {
    url="$1"
    file="$SOURCES/$(basename "$url")"
    echo "  extracting $(basename "$file")..."
    tar -xf "$file" -C "$BUILD_DIR"
}

# mostra o passo atual
step() {
    echo "==> $*"
}
