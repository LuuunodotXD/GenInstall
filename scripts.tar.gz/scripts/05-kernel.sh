#!/bin/sh
# 05-kernel.sh — build do kernel linux
. "$(dirname "$0")/common.sh"

VERSION=6.1.187
URL="https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-$VERSION.tar.xz"

step "kernel $VERSION"

# o tarball já foi baixado pelo 02-linux-headers.sh
[ ! -f "$SOURCES/linux-$VERSION.tar.xz" ] && fetch "$URL"
[ ! -d "$BUILD_DIR/linux-$VERSION" ] && extract "$URL"

cd "$BUILD_DIR/linux-$VERSION"

# usa o config do projeto se existir
if [ -f "$BASEROOT_DIR/config/kernel.config" ]; then
    cp "$BASEROOT_DIR/config/kernel.config" .config
    make ARCH=x86_64 olddefconfig
else
    # defconfig pra ter suporte amplo a hardware
    make ARCH=x86_64 defconfig
fi

make ARCH=x86_64 -j"$JOBS"

# instala o kernel no staging base
mkdir -p "$BASE/boot"
cp arch/x86/boot/bzImage "$BASE/boot/vmlinuz"

echo "  kernel $VERSION done."
