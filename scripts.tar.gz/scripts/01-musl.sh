#!/bin/sh
# 01-musl.sh — build da musl libc
. "$(dirname "$0")/common.sh"

VERSION=1.2.5
URL="https://musl.libc.org/releases/musl-$VERSION.tar.gz"

step "musl $VERSION"

fetch "$URL"
extract "$URL"

cd "$BUILD_DIR/musl-$VERSION"

./configure \
    --prefix=/usr \
    --syslibdir=/lib \
    CFLAGS="$CFLAGS"

make -j"$JOBS"
make DESTDIR="$BASE" install

echo "  musl $VERSION done."
