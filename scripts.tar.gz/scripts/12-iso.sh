#!/bin/sh
# 12-iso.sh — empacota os grupos e gera a ISO do BaseRoot Linux
. "$(dirname "$0")/common.sh"

step "packaging groups"

# empacota cada grupo de pacotes
for group in base network utils extra scripts; do
    staging="$ROOTFS/$group"
    out="$ISO_DIR/packages/$group.tar.bz2"
    # só empacota se o staging não estiver vazio
    if [ "$(ls -A "$staging" 2>/dev/null)" ]; then
        echo "  packing $group..."
        tar -cjf "$out" -C "$staging" .
    else
        echo "  skipping $group (empty)"
    fi
done

step "setting up boot"

# copia o kernel pra iso
cp "$BASE/boot/vmlinuz" "$ISO_DIR/boot/"

# copia o limine pra iso e configura
LIMINE_DATA="$UTILS/usr/share/limine"
cp "$LIMINE_DATA/limine-bios.sys" "$ISO_DIR/boot/"
cp "$LIMINE_DATA/limine-bios-cd.bin" "$ISO_DIR/boot/"
cp "$LIMINE_DATA/limine-uefi-cd.bin" "$ISO_DIR/boot/"
mkdir -p "$ISO_DIR/EFI/BOOT"
cp "$LIMINE_DATA/BOOTX64.EFI" "$ISO_DIR/EFI/BOOT/"

# cria o limine.conf
cat > "$ISO_DIR/boot/limine.conf" << 'EOF'
timeout: 5

/BaseRoot Linux
    protocol: linux
    kernel_path: boot():/boot/vmlinuz
    kernel_cmdline: rdinit=/sbin/init quiet
EOF

step "generating ISO"

xorriso -as mkisofs \
    -b boot/limine-bios-cd.bin \
    -no-emul-boot -boot-load-size 4 -boot-info-table \
    --efi-boot boot/limine-uefi-cd.bin \
    -efi-boot-part --efi-boot-image \
    --protective-msdos-label \
    -o "$OUTPUT/baseroot-linux-x86_64.iso" \
    "$ISO_DIR"

# instala o limine no setor de boot da iso (BIOS)
"$UTILS/usr/bin/limine" bios-install "$OUTPUT/baseroot-linux-x86_64.iso"

echo "  iso ready: $OUTPUT/baseroot-linux-x86_64.iso"
