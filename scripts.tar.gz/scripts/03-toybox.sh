#!/bin/sh
# 03-toybox.sh — build do toybox (userland estático)
. "$(dirname "$0")/common.sh"

VERSION=0.8.11
URL="https://landley.net/toybox/downloads/toybox-$VERSION.tar.gz"

step "toybox $VERSION"

fetch "$URL"
extract "$URL"

cd "$BUILD_DIR/toybox-$VERSION"

# usa o config do projeto se existir, senão usa defconfig
if [ -f "$BASEROOT_DIR/config/toybox.config" ]; then
    cp "$BASEROOT_DIR/config/toybox.config" .config
else
    make defconfig
fi

make CFLAGS="$CFLAGS -static" -j"$JOBS"
make PREFIX="$BASE" install

echo "  toybox $VERSION done."
