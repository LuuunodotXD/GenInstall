#!/bin/sh
# 06-libressl.sh — build do LibreSSL
. "$(dirname "$0")/common.sh"

VERSION=3.9.2
URL="https://ftp.openbsd.org/pub/OpenBSD/LibreSSL/libressl-$VERSION.tar.gz"

step "libressl $VERSION"

fetch "$URL"
extract "$URL"

cd "$BUILD_DIR/libressl-$VERSION"

./configure \
    --prefix=/usr \
    --enable-static \
    --disable-shared \
    CFLAGS="$CFLAGS"

make -j"$JOBS"
make DESTDIR="$NETWORK" install

echo "  libressl $VERSION done."
