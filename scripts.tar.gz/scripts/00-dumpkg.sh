#!/bin/sh
# 00-dumpkg.sh — instala o dumpkg no staging base
. "$(dirname "$0")/common.sh"

DUMPKG_DIR="$BASEROOT_DIR/dumpkg"

step "dumpkg"

# verifica se o diretório do dumpkg existe
if [ ! -d "$DUMPKG_DIR" ]; then
    echo "error: dumpkg directory not found at $DUMPKG_DIR"
    echo "clone or copy the dumpkg repo into $DUMPKG_DIR first."
    exit 1
fi

# cria os diretórios necessários no staging
mkdir -p \
    "$BASE/usr/bin" \
    "$BASE/usr/share/dumpkg" \
    "$BASE/etc/dumpkg" \
    "$BASE/usr/dumpkg/recipes" \
    "$BASE/usr/dumpkg/installed" \
    "$BASE/usr/dumpkg/files" \
    "$BASE/var/log"

# instala os scripts em /usr/bin
for cmd in dumpkg dumpkg-init dumpkg-install dumpkg-remove dumpkg-update; do
    src="$DUMPKG_DIR/scripts/$cmd"
    if [ ! -f "$src" ]; then
        echo "error: '$src' not found."
        exit 1
    fi
    install -m755 "$src" "$BASE/usr/bin/$cmd"
done

# instala o dumpkg-common em /usr/share/dumpkg
install -m644 "$DUMPKG_DIR/scripts/dumpkg-common" "$BASE/usr/share/dumpkg/dumpkg-common"

# cria o dumpkg.conf com valores padrão
cat > "$BASE/etc/dumpkg/dumpkg.conf" << 'EOF'
# dumpkg configuration file
# edit this to fit your setup

# url to fetch the recipes tarball from
recipes_url=https://example.com/recipes.tar.gz

# checksum verification: none, md5, sha256
checksum=md5

# which downloader to use: curl, wget
downloader=wget
EOF

# cria o info-dumpkg
cat > "$BASE/etc/dumpkg/info-dumpkg" << 'EOF'
version=0.1
EOF

# cria o log vazio
touch "$BASE/var/log/dumpkg.log"

echo "  dumpkg done."
