#!/bin/sh
# 11-nano.sh — build do nano (editor de texto)
. "$(dirname "$0")/common.sh"

VERSION=8.2
URL="https://www.nano-editor.org/dist/v8/nano-$VERSION.tar.xz"

step "nano $VERSION"

fetch "$URL"
extract "$URL"

cd "$BUILD_DIR/nano-$VERSION"

./configure \
    --prefix=/usr \
    --enable-static \
    --disable-nls \
    CFLAGS="$CFLAGS"

make -j"$JOBS"
make DESTDIR="$EXTRA" install

echo "  nano $VERSION done."
