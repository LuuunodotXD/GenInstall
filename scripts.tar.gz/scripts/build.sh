#!/bin/sh
# build.sh — orquestra o build completo do BaseRoot Linux
# uso: sh build.sh [script] (sem argumento roda tudo)

set -e

SCRIPTS="$(dirname "$0")/scripts"

# cria os diretórios necessários
mkdir -p \
    sources build output \
    rootfs/base rootfs/network rootfs/utils rootfs/extra rootfs/scripts \
    iso/boot iso/packages

# se passar um script específico, roda só ele
if [ -n "$1" ]; then
    script="$SCRIPTS/$1"
    if [ ! -f "$script" ]; then
        echo "error: script '$1' not found."
        echo "available scripts:"
        ls "$SCRIPTS"/[0-9]*.sh | xargs -n1 basename
        exit 1
    fi
    echo "==> running $1"
    sh "$script"
    exit 0
fi

# roda todos os scripts em ordem
echo "==> building baseroot linux"
echo ""

for script in "$SCRIPTS"/[0-9]*.sh; do
    sh "$script"
    echo ""
done

echo "==> all done."
