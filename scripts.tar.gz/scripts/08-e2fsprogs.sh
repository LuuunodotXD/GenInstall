#!/bin/sh
# 08-e2fsprogs.sh — build do e2fsprogs (ferramentas ext2/3/4)
. "$(dirname "$0")/common.sh"

VERSION=1.47.1
URL="https://downloads.sourceforge.net/project/e2fsprogs/e2fsprogs/v$VERSION/e2fsprogs-$VERSION.tar.gz"

step "e2fsprogs $VERSION"

fetch "$URL"
extract "$URL"

# e2fsprogs prefere build fora do source dir
mkdir -p "$BUILD_DIR/e2fsprogs-$VERSION/build"
cd "$BUILD_DIR/e2fsprogs-$VERSION/build"

../configure \
    --prefix=/usr \
    --enable-static \
    --disable-shared \
    --disable-nls \
    CFLAGS="$CFLAGS"

make -j"$JOBS"
make DESTDIR="$UTILS" install

echo "  e2fsprogs $VERSION done."
